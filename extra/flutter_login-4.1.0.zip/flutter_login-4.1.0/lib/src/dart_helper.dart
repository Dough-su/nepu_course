class DartHelper {
  static bool isNullOrEmpty(String? value) => value == '' || value == null;
}
