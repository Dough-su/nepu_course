import 'package:flutter/material.dart';

class LoginThemeHelper {
  /// used by the next screen after login to style the after-hero text
  static TextStyle? loginTextStyle;
}
